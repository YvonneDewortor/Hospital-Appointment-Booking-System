import { Component, OnInit } from '@angular/core';
import { ProviderService } from 'src/app/services/provider.service';
import { ControllersService } from 'src/app/services/controllers.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.page.html',
  styleUrls: ['./forgot.page.scss'],
})
export class ForgotPage implements OnInit {
  formData: any = {};

  constructor(private providerSvc: ProviderService, public ctrl: ControllersService, public router: Router) { }

  ngOnInit() {
  }

  Forgot() {
    if (this.formData.email != null) {
      if (this.formData.email.match(this.ctrl.pattern.email)) {
        this.ctrl.presentLoading();
        let dataPost = new FormData();
        dataPost.append('inputEmailAddress', this.formData.email);
        this.providerSvc.postData('mobile_forgot.php', dataPost).subscribe(res => {
          if (res == "1") {
            this.ctrl.alertPopUp("", "An email has been sent to you with instructions on how to reset your password", "OK");
            this.router.navigate(['login']);
          } else {
            this.ctrl.alertPopUp("Attention", "Email Does Not Exist", "OK");
          }
        }, error => {
          console.log(error);
        });
      } else {
        this.ctrl.alertPopUp("Attention", "Invalid Email Format", "OK");
      }
    } else {
      this.ctrl.alertPopUp("Attention", "Please Fill Up", "OK");
    }
  }

}
