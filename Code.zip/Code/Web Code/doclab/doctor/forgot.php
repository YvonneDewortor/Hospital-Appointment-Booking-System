<?php

require_once '../config/autoload.php';
require_once './includes/path.inc.php';

include EMAIL_HELPER;

$errors = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = escape_input($_POST["inputEmailAddress"]);

    $forgotstmt = $conn->prepare("SELECT * FROM doctors WHERE doctor_email = ?");
    $forgotstmt->bind_param("s", $email);
    $forgotstmt->execute();
    $result = $forgotstmt->get_result();
    $r = $result->fetch_assoc();

    $doctor_id = $r['doctor_id'];

    if (empty($email)) {
        array_push($errors, "Email Address is required");
    } else if ($result->num_rows != 1) {
        array_push($errors, "Email Not Exist");
    } else {
        email_validation($email);
    }
}
?>
<!DOCTYPE html>
<html>

<head>
	<?php include CSS_PATH;?>
	<link rel="stylesheet" href="../assets/css/clinic/login.css">
</head>

<script type='text/javascript'>

$(document).ready(function(){
	$('input#forgotbtn').on('click', function(){
		var f = $('form#forgotform');

		$(this).prop('disabled', true);

		$(f).submit();
	});
});

function disableButtons()
{
  $('input[type="submit"]').attr('disabled', true);
}
</script>

<body>
	<div class="container">
		<div class="login-wrap mx-auto">
			<div class="login-head">
				<h4><?php echo $BRAND_NAME; ?></h4>
				<p>Forgot Password</p>
			</div>
			<div class="login-body">
				<form id = "forgotform" name="forgot_form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<?=display_error();?>
					<div class="form-group">
						<label for="inputEmailAddress">Email address</label>
						<input type="email" name="inputEmailAddress" class="form-control" id="inputEmailAddress" aria-describedby="emailHelp" placeholder="example@email.com">
						<small id="emailHelp" class="form-text text-muted">Provide us the email id/ mobile of your GHC account<br> We will send you an email with instructions to reset your password.</small>
					</div>
					<input type='hidden' name='dothis' value=''>
					<input type="submit" id="forgotbtn" name="forgotbtn" class="btn btn-primary btn-block button" value="Send Me"></input>
					</form>
			</div>
			<div class="login-footer">
				<p class="text-muted"><a href="login.php"><i class="fa fa-long-arrow-alt-left"></i> Back</a></p>
			</div>
		</div>
	</div>
	<?php include JS_PATH;?>
</body>
</html>
<?php

if (isset($_POST['dothis'])) {

    if (count($errors) == 0) {
        $selector = bin2hex(random_bytes(8));
        $validator = random_bytes(32);
        $link = $_SERVER["SERVER_NAME"] . "/doclab/doctor/reset.php?selector=" . $selector . "&validator=" . bin2hex($validator);
        $expries = date("U") + 1800;

        $key = md5($email);
        $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
        $key = $key . $addKey;

        $userEmail = $_POST["inputEmailAddress"];

        $hashedToken = password_hash($validator, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO doctor_reset (reset_email, `key`, reset_selector, reset_token, reset_expires) VALUE (?,?,?,?,?)");
        $stmt->bind_param("sssss", $userEmail, $key, $selector, $hashedToken, $expries);
        $stmt->execute();

        $stmt->close();
    }

    $output = '<p>Dear user,</p>';
    $output .= '<p>Please click on the following link to reset your password.</p>';
    $output .= '<p>-------------------------------------------------------------</p>';
    $output .= '<p><a href="http://localhost:8080/doclab/doctor/reset.php?key=' . $key . '&email=' . $email . '&action=reset" target="_blank">
	http://localhost:8080/doclab/doctor/reset.php?key=' . $key . '&email=' . $email . '&action=reset</a></p>';
    $output .= '<p>-------------------------------------------------------------</p>';
    $output .= '<p>You can also copy the entire link into your browser.
	The link will expire after 1 day for security reason.</p>';
    $output .= '<p>If you did not request this forgotten password email, no action
	is needed, your password will not be reset. However, you may want to log into
	your account and change your security password as someone may have guessed it.</p>';
    $output .= '<p>Thanks,</p>';
    $output .= '<p>GHC Appointments</p>';
    $body = $output;
    $subject = "Password Recovery - GHC Appointments";

    $email_to = $email;
    $fromserver = "noreply@ghc.com";
    require "../PHPMailer/PHPMailerAutoload.php";
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "yvonnedewortor@gmail.com";
    $mail->Password = "ellen1999";
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->IsHTML(true);
    $mail->From = "noreply@ghc.com";
    $mail->FromName = "GHC Appointments";
    $mail->Sender = $fromserver; 
    $mail->Subject = $subject;
    $mail->Body = $body;
    $mail->AddAddress($email_to);
    if (!$mail->Send()) {
        echo "<script>Swal.fire('Oops...','Failed to Send Email! Try Again!','error')</script>";
} else {
        echo "<script>Swal.fire('Great !','An email has been sent to you with instructions on how to reset your password','success')</script>";
}
} else {
}