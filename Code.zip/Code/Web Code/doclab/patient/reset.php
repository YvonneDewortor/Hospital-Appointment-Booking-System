<?php
require_once '../config/autoload.php';
//require_once './includes/path.inc.php';

$error = "";
$BRAND_NAME = "GHC Appointments";
$PAGE_TITLE = "Reset Password";
?>
<!DOCTYPE html>
<html>

<head>
	<?php include CSS_PATH;?>
	<link rel="stylesheet" href="../assets/css/clinic/login.css">
</head>
<body>
	<?php

$key = $_GET["key"];
$email = $_GET["email"];
$action = $_GET["action"];
$curDate = date("Y-m-d", time());
$query = mysqli_query($conn,
    "SELECT * FROM `patient_reset` WHERE `key`='" . $key . "' and `reset_email`='" . $email . "';"
);
$row = mysqli_num_rows($query);
if ($row == "") {
    $error .= '<h2>Invalid Link</h2>
			<p>The link is invalid/expired. Either you did not copy the correct link
			from the email, or you have already used the key in which case it is
			deactivated.</p>
			<p><a href="http://localhost:8080/doclab/patient/forgot.php">
			Click here</a> to reset password.</p>';
} else {
    $row = mysqli_fetch_assoc($query);
    $expries = time()+86400;
    if ($expries <= $curDate) {
        ?>
				<br />

	<div class="container">
		<div class="login-wrap mx-auto">
			<div class="login-head">
				<h4><?php echo "USER"; ?></h4>
				<p>Reset your password</p>
			</div>
			<div class="login-body">
				<form name="forgot_form" method="POST" action="<?php echo htmlspecialchars($_SERVER["REQUEST_URI"]); ?>">
				<input type="hidden" name="action" value="<?=$action?>">
				<input type="hidden" name="key" value="<?=$key?>">
				<input type="hidden" name="email" value="<?=$email?>">
				<div class="form-group">
						<p>You have requested to reset the password for <strong><?=$email?></strong></p>
					</div>

					<div class="form-group">
						<label for="inputPassword">Password</label>
						<input type="password" name="inputPassword" class="form-control" id="inputPassword" placeholder="New Password">
					</div>
					<div class="form-group">
						<label for="inputConfirmPassword">Confirm Password</label>
						<input type="password" name="inputConfirmPassword" class="form-control" id="inputConfirmPassword" placeholder="Retype New Password">
					</div>
					<button type="submit" name="resetbtn" class="btn btn-primary btn-block button">Reset Password</button>
				</form>
			</div>
		</div>
	</div>

	<?php
} else {
        echo "Hello";
        $error .= "<h2>Link Expired</h2>
		<p>The link is expired. You are trying to use the expired link which
		as valid only 24 hours (1 days after request).<br /><br /></p>";
    }
}
if ($error != "") {
    echo "<div class='error'>" . $error . "</div><br />";
}
if (isset($_POST["email"]) && isset($_POST["action"]) &&
    ($_POST["action"] == "reset")) {
    $error = "";
    $inputPassword = mysqli_real_escape_string($conn, $_POST["inputPassword"]);
    $inputConfirmPassword = mysqli_real_escape_string($conn, $_POST["inputConfirmPassword"]);
    $email = $_POST["email"];
    $curDate = date("Y-m-d", time());
    if ($inputPassword != $inputConfirmPassword) {
        $error .= "<p>Password do not match, both password should be same.<br /><br /></p>";
    }
	$check = $conn->prepare("SELECT * FROM patients WHERE patient_email = ? ");
    $check->bind_param("s", $email);
    $check->execute();
    $q = $check->get_result();
    $r = $q->fetch_assoc();
    if ($error != "") {
        echo "<div class='error'>" . $error . "</div><br />";
    } else {
			$token = $r["patient_token"];
			$inputPassword = $conn->real_escape_string(md5($_POST['inputPassword']));
			$enpass = encrypt($inputPassword, $token);
	        mysqli_query($conn,
            "UPDATE `patients` SET `patient_password`='" . $enpass . "' WHERE `patient_email`='" . $email . "';"
        );

        mysqli_query($conn, "DELETE FROM `patient_reset` WHERE `reset_email`='" . $email . "';");
        echo "<script>Swal.fire('Great !','Your password has been updated successfully. Visit your app to login','success')</script>";
       }
}
?>
	<?php include JS_PATH;?>
	</body>
</html>