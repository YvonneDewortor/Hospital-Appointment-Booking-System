<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header("Content-Type: application/json; charset=UTF-8");


require_once '../config/autoload.php';

include EMAIL_HELPER;

$PAGE_TITLE = "Forgot Password";
$errors = array();


    $email = escape_input($_POST["inputEmailAddress"]);
    $forgotstmt = $conn->prepare("SELECT * FROM patients WHERE patient_email = ?");
    $forgotstmt->bind_param("s", $email);
    $forgotstmt->execute();
    $result = $forgotstmt->get_result();
    $r = $result->fetch_assoc();

    $selector = bin2hex(random_bytes(8));
    $validator = random_bytes(32);
    $link = $_SERVER["SERVER_NAME"] . "/doclab/doctor/reset.php?selector=" . $selector . "&validator=" . bin2hex($validator);
    $expries = date("U") + 1800;

    $key = md5($email);
    $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
    $key = $key . $addKey;

    $patient_id = $r['patient_id'];

    $userEmail = $_POST["inputEmailAddress"];

    $hashedToken = password_hash($validator, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO patient_reset (reset_email, `key`, reset_selector, reset_token, reset_expires) VALUE (?,?,?,?,?)");
    $stmt->bind_param("sssss", $userEmail, $key, $selector, $hashedToken, $expries);
    $stmt->execute();

    $stmt->close();



?>
<?php
    $output = '<p>Dear user,</p>';
    $output .= '<p>Please click on the following link to reset your password.</p>';
    $output .= '<p>-------------------------------------------------------------</p>';
    $output .= '<p><a href="http://192.168.8.137:8080/doclab/patient/reset.php?key=' . $key . '&email=' . $email . '&action=reset" target="_blank">
	http://192.168.8.137:8080/doclab/patient/reset.php?key=' . $key . '&email=' . $email . '&action=reset</a></p>';
    $output .= '<p>-------------------------------------------------------------</p>';
    $output .= '<p>You can also copy the entire link into your browser.
	The link will expire after 1 day for security reason.</p>';
    $output .= '<p>If you did not request this forgotten password email, no action
	is needed, your password will not be reset. However, you may want to log into
	your account and change your security password as someone may have guessed it.</p>';
    $output .= '<p>Thanks,</p>';
    $output .= '<p>GHC Appointments</p>';
    $body = $output;
    $subject = "Password Recovery - GHC Appointments";

    $email_to = $email;
    $fromserver = "noreply@ghc.com";
    require "../PHPMailer/PHPMailerAutoload.php";
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = "smtp.gmail.com"; 
    $mail->SMTPAuth = true;
    $mail->Username = "yvonnedewortor@gmail.com"; 
    $mail->Password = "ellen1999"; 
    $mail->SMTPSecure = "ssl";
    $mail->Port = 465;
    $mail->IsHTML(true);
    $mail->From = "noreply@ghc.com";
    $mail->FromName = "GHC Appointments";
    $mail->Sender = $fromserver; 
    $mail->Subject = $subject;
    $mail->Body = $body;
    $mail->AddAddress($email_to);
    if (!$mail->Send()) {
        echo "0";
        
    } else {
        echo "1";
        
    }
