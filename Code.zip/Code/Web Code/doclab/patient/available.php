<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include("../config/database.php");

$contentdata = file_get_contents("php://input");
$getdata = json_decode($contentdata);
$date = date("Y-m-d");
$query = "SELECT * FROM schedule s LEFT JOIN schedule_detail sd ON sd.schedule_id = s.schedule_id";
$result = $conn->query($query);

	if ($result->num_rows < 0) {
		echo json_encode(array("No Schedule Found"));
	} else {
		$arr = array();
		while ($row = $result->fetch_assoc()) {

			$day = $row['schedule_day'];
			$dayofweek = date("l", strtotime($date));

			if ($dayofweek == $day) {
				$arr[] = $row;
			}
		}

		echo json_encode($arr);
		mysqli_close($conn);
	}

